
from django.urls import path, include
from . import views
from rest_framework import routers

router = routers.DefaultRouter()
router.register('Customer', views.CustomerView)
router.register('Item', views.ItemView)
router.register('Order', views.OrderView)

urlpatterns = [
    path('',include(router.urls)),
    path(r'^openid/', include('oidc_provider.urls', namespace='oidc_provider')),
    path('api-auth/',  include('rest_framework.urls'))
]