from django.db import models


# Create your models here.

class Customer(models.Model):
  
    name = models.CharField(max_length=150)
    email = models.EmailField(max_length=254)
    phone = models.IntegerField()

    def __str__(self):
        return self.name



class Item(models.Model):
    name = models.CharField(max_length=150)
    price = models.IntegerField()

    def __str__(self):
        return self.name

    
class Order(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    item = models.ForeignKey(Item,on_delete=models.CASCADE)
    amount = models.IntegerField()
    time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.item

    
